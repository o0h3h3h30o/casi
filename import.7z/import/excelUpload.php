
<?php

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);


require('library/php-excel-reader/excel_reader2.php');
require('library/SpreadsheetReader.php');

$dbHost = "localhost";
$dbDatabase = "casi";
$dbPasswrod = "";
$dbUser = "root";
$mysqli = new mysqli($dbHost, $dbUser, $dbPasswrod, $dbDatabase);

if(isset($_POST['Submit']))
{
	
    $mimes = array('application/vnd.ms-excel','text/xls','text/xlsx','application/vnd.oasis.opendocument.spreadsheet','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    if(in_array($_FILES["file"]["type"],$mimes))
    {
        $uploadFilePath = 'uploads/'.basename($_FILES['file']['name']);
		
		move_uploaded_file($_FILES['file']['tmp_name'], $uploadFilePath);
        $Reader = new SpreadsheetReader($uploadFilePath);

		$totalSheet = count($Reader->sheets());
		/* For Loop for all sheets */
        for($i=0;$i<$totalSheet;$i++)
        {
            $Reader->ChangeSheet($i);
            foreach ($Reader as $Row)
            {
            
                $session = isset($Row[0]) ? $Row[0] : '';
                $rs = isset($Row[1]) ? $Row[1] : '';
				$money_tai = isset($Row[2]) ? $Row[2] : '';
				$money_xiu = isset($Row[3]) ? $Row[3] : '';
				$bot_tai = isset($Row[4]) ? $Row[4] : '';
				$bot_xiu = isset($Row[5]) ? $Row[5] : '';
				if($session>0){
					$queryde = "DELETE FROM tbl_faketx WHERE `session` = '".$session."'";
					$mysqli->query($queryde);
					$query = "insert into tbl_faketx(session,result,money_tai,money_xiu,num_tai,num_xiu) values('".$session."','".$rs."','".$money_tai."','".$money_xiu."','".$bot_tai."','".$bot_xiu."')";
					$mysqli->query($query);
				}
            }
        }
        

            echo "<br />Them thanh cong";
			echo "<br> <a href = '/admin/import/index-1.php'>Quay lai</a>";
        }
        else
        {
            die("<br/>Sorry, File type is not allowed. Only Excel file.");
        }
}
?>